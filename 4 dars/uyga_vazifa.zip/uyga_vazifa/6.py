dict1 = {'a': 1, 'b': 2}
dict2 = {'c': 3, 'd': 4}
dict3 = {'e': 5, 'f': 6}
sssr = {}
sssr.update(dict1)
sssr.update(dict2)
sssr.update(dict3)
print("BMT:", sssr)
