N = int(input("N sonini kiriting: "))
d = {}
for i in range(1, N):
    d[i] = i**2
print(d)