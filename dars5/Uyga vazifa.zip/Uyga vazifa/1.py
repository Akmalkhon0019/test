a = []
b = int(input("Son kiriting >>>: "))
c = int(input("Son kiriting >>>: "))
i = 1
eskiB = b
while b < c:
    i+=1
    b*=eskiB
print(i)