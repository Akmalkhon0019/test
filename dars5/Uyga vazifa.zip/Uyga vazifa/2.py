darslik = [('English', 88), ('Science', 90), ('Maths', 97), ('Social sciences', 82)]
tartib = sorted(darslik, key=lambda x: x[1])
print(tartib)
