while i <= b:
