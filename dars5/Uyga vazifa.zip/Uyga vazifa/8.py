n = int(input("sonlarni kiriting >>>: "))
def chap(K):
    return int(str(K) + str(n))
K = int(input("K ni kiriting>>>: "))
print(chap(K))