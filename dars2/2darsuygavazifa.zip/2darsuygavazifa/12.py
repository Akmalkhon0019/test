sonlar = []
n = int(input("Nechta son kiritmoqchisiz: "))
for i in range(n):
    son = float(input(f"{i + 1}-sonni kiriting: "))
    sonlar.append(son)

navbat = True
for i in range(1, len(sonlar)):
    if i % 2 == 1:
        if sonlar[i] <= sonlar[i - 1]:
            navbat = False
            break
    else:
        if sonlar[i] >= sonlar[i - 1]:
            navbat = False
            break
if navbat:
    print("Ketma-ketlik navbat o'zgaruvchan.")
else:
    print("Ketma-ketlik navbat o'zgaruvchan emas.")
